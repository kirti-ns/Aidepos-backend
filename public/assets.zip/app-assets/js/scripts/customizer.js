! function(a, e, t) {
    "use strict";
    t(".customizer-toggle").on("click", function() {
        t(".customizer").toggleClass("open")
    }), t(".customizer-close").on("click", function() {
        t(".customizer").removeClass("open")
    }), 0 < t(".customizer-content").length && t(".customizer-content").perfectScrollbar({
        theme: "dark"
    });
    var s = t("body"),
        n = t("nav.header-navbar"),
        o = t("div.header-navbar"),
        r = t("footer"),
        i = t(".main-menu"),
        l = s.data("menu"),
        c = !1,
        d = !1,
        m = !1;
    n.hasClass("navbar-semi-light") && (d = !0), n.hasClass("navbar-semi-dark") && (m = !0), "horizontal-menu" == l && (c = !0, t(".layout-options .navbar").parent(".nav-item").attr("style", "display: none !important"), t(".color-options .nav-semi-light").parent(".nav-item").attr("style", "display: none !important"), t(".color-options .nav-semi-dark").parent(".nav-item").attr("style", "display: none !important"), t("#native-scroll").parent(".custom-checkbox").attr("style", "display: none !important"), t("#bordered-navigation").parent(".custom-checkbox").attr("style", "display: none !important"), t("#collapsible-navigation").parent(".custom-checkbox").attr("style", "display: none !important"), t("#static-navigation").parent(".custom-checkbox").attr("style", "display: none !important"), t("#flipped-navigation").parent(".custom-checkbox").attr("style", "display: none !important"), t(".color-options li:eq(3) a").tab("show")), "vertical-compact-menu" !== l && "vertical-content-menu" !== l && "vertical-overlay-menu" !== l || (t(".color-options a#color-opt-3").tab("show"), "vertical-content-menu" === l && t(".color-options a#color-opt-4").tab("show"), "vertical-compact-menu" !== l && "vertical-overlay-menu" !== l || t("#boxed-layout").parent(".custom-checkbox").attr("style", "display: none !important"), t(".color-options .nav-semi-light").parent(".nav-item").attr("style", "display: none !important"), t(".color-options .nav-semi-dark").parent(".nav-item").attr("style", "display: none !important")), "vertical-overlay-menu" === l && (t("#collapsed-sidebar").prop("checked", !0), t("#static-layout").parent(".custom-checkbox").attr("style", "display: none !important"), t("#static-navigation").parent(".custom-checkbox").attr("style", "display: none !important")), t("#collapsed-sidebar").on("click", function() {
        t.app.menu.toggle(), setTimeout(function() {
            t(a).trigger("resize")
        }, 100)
    }), t("#fixed-layout").on("click", function() {
        !0 === t("#boxed-layout").prop("checked") && t("#boxed-layout").trigger("click"), !0 === t(this).prop("checked") ? (s.hasClass("fixed-navbar") || !1 !== c || s.addClass("fixed-navbar"), n.hasClass("fixed-top") || !1 !== c || n.addClass("fixed-top"), r.hasClass("navbar-fixed-bottom") || r.addClass("navbar-fixed-bottom"), o.hasClass("navbar-fixed") || !0 !== c || o.addClass("navbar-fixed"), n.removeClass("navbar-static-top"), o.removeClass("navbar-static"), i.removeClass("menu-static"), r.removeClass("footer-static")) : r.removeClass("navbar-fixed-bottom")
    }), t("#boxed-layout").on("click", function() {
        !0 === t("#fixed-layout").prop("checked") && t("#fixed-layout").trigger("click"), !0 === t(this).prop("checked") ? (s.hasClass("container boxed-layout") || s.addClass("container boxed-layout"), n.hasClass("container boxed-layout") || n.addClass("container boxed-layout"), n.removeClass("navbar-static-top"), i.removeClass("menu-static"), r.removeClass("footer-static")) : (s.removeClass("container boxed-layout"), n.removeClass("container boxed-layout"))
    }), t("#static-layout").on("click", function() {
        !0 === t(this).prop("checked") ? (n.hasClass("navbar-static-top") || n.addClass("navbar-static-top"), i.hasClass("menu-static") || i.addClass("menu-static"), r.hasClass("footer-static") || r.addClass("footer-static"), !0 === c && (o.unstick(), o.addClass("navbar-static")), s.removeClass("fixed-navbar"), n.removeClass("fixed-top"), o.removeClass("menu-fixed"), i.removeClass("menu-fixed"), r.removeClass("navbar-fixed-bottom"), t.app.menu.manualScroller.disable()) : (!1 === c && (s.addClass("fixed-navbar"), i.removeClass("navbar-static").addClass("menu-fixed"), n.removeClass("navbar-static-top").addClass("fixed-top")), !0 === c && (o.sticky(), o.removeClass("navbar-static").addClass("navbar-fixed")), r.removeClass("footer-static"), t.app.menu.manualScroller.enable())
    }), "vertical-overlay-menu" === l && t("#brand-center").prop("checked", !0), t("#brand-center").on("click", function() {
        n.hasClass("navbar-brand-center") ? (1 == d && (n.removeClass("navbar-dark navbar-brand-center"), h("dark"), n.addClass("navbar-semi-light")), 1 == m && (n.removeClass("navbar-dark navbar-brand-center"), h("light"), n.addClass("navbar-semi-dark"))) : (1 == d && n.removeClass("navbar-semi-light"), 1 == m && n.removeClass("navbar-semi-dark"), n.addClass("navbar-dark navbar-brand-center"), h("light"))
    }), t("#navbar-static-top").on("click", function() {
        !0 === t(this).prop("checked") ? (n.hasClass("navbar-static-top") || n.addClass("navbar-static-top"), i.hasClass("menu-static") || i.addClass("menu-static"), r.hasClass("footer-static") || r.addClass("footer-static"), s.removeClass("fixed-navbar"), n.removeClass("fixed-top"), i.removeClass("menu-fixed"), r.removeClass("navbar-fixed-bottom"), t.app.menu.manualScroller.disable()) : (s.addClass("fixed-navbar"), n.removeClass("navbar-static-top").addClass("fixed-top"), i.removeClass("menu-static").addClass("menu-fixed"), r.removeClass("footer-static"), t.app.menu.manualScroller.enable())
    }), t("#native-scroll").on("click", function() {
        !0 === t("#static-navigation").prop("checked") && (i.removeClass("menu-static").addClass("menu-fixed"), t("#static-navigation").attr("checked", !1)), i.hasClass("menu-native-scroll") ? (i.removeClass("menu-native-scroll"), t.app.menu.manualScroller.enable()) : (i.addClass("menu-native-scroll"), t.app.menu.manualScroller.disable())
    }), t("#right-side-icons").on("click", function() {
        i.hasClass("menu-icon-right") ? i.removeClass("menu-icon-right") : i.addClass("menu-icon-right"), !0 === c && (o.hasClass("navbar-icon-right") ? o.removeClass("navbar-icon-right") : o.addClass("navbar-icon-right"))
    }), t("#bordered-navigation").on("click", function() {
        i.hasClass("menu-bordered") ? i.removeClass("menu-bordered") : i.addClass("menu-bordered")
    }), t("#flipped-navigation").on("click", function() {
        s.hasClass("menu-flipped") ? s.removeClass("menu-flipped") : (s.addClass("menu-flipped"), t(".customizer-close").trigger("click")), !0 === c && (o.hasClass("navbar-flipped") ? o.removeClass("navbar-flipped") : o.addClass("navbar-flipped"))
    }), t("#collapsible-navigation").on("click", function() {
        i.hasClass("menu-collapsible") ? i.removeClass("menu-collapsible") : i.addClass("menu-collapsible")
    }), t("#static-navigation").on("click", function() {
        !0 === t("#native-scroll").prop("checked") && (i.removeClass("menu-native-scroll"), t("#native-scroll").attr("checked", !1)), i.hasClass("menu-static") ? (i.removeClass("menu-static").addClass("menu-fixed"), t.app.menu.manualScroller.enable()) : (i.addClass("menu-static").removeClass("menu-fixed"), t.app.menu.manualScroller.disable())
    }), t(".main-menu").hasClass("menu-dark") ? t(".customizer-sidebar-options").find('[data-sidebar="menu-dark"]').addClass("active").siblings("btn").removeClass("active") : t(".customizer-sidebar-options").find('[data-sidebar="menu-light"]').addClass("active").siblings("btn").removeClass("active"), t(".customizer-sidebar-options .btn").on("click", function() {
        var a = t(this),
            e = a.attr("data-sidebar");
        a.addClass("active").siblings(".btn").removeClass("active"), t(".main-menu").removeClass("menu-dark menu-light").addClass(e), !0 === c && (o.removeClass("navbar-dark navbar-light"), "menu-light" == e ? o.addClass("navbar-light") : o.addClass("navbar-dark"))
    });
    var v = t("nav.header-navbar"),
        b = "";

    function p(a) {
        if (a.attr("class").match(/\bbg-\S+/g)) {
            b = a.attr("class").match(/\bbg-\S+/g);
            var s = "";
            t.map(b, function(a, e) {
                s = 0 === e ? a : s + " " + a
            }), b = s
        } else b = "";
        return b
    }

    function u(a) {
        a.removeClass("navbar-semi-dark navbar-semi-light navbar-light navbar-dark navbar-shadow " + b);
        var e = "";
        t(".navbar-header").attr("class").match(/\bbg-\S+/g) && (e = t(".navbar-header").attr("class").match(/\bbg-\S+/g)[0]), t(".navbar-header").removeClass(e)
    }

    function C(a, e) {
        a.addClass(e)
    }

    function h(a) {
        "light" == a ? t(".brand-logo").attr("src", "../../../app-assets/images/logo/logo-light-sm.png") : t(".brand-logo").attr("src", "../../../app-assets/images/logo/logo-dark-sm.png")
    }
    v.attr("class").match(/\bbg-\S+/g) && (b = v.attr("class").match(/\bbg-\S+/g)[0]), t(".nav-semi-light").on("click", function() {
        p(v), h("dark"), u(v), C(v, "navbar-semi-light bg-gradient-x-grey-blue"), t("input[name=nav-slight-clr].default").prop("checked", !0), m = !(d = !0)
    }), t("input[name='nav-slight-clr']").change(function() {
        1 == m && v.removeClass("navbar-semi-dark").addClass("navbar-semi-light"), b = p(v), v.removeClass(b).addClass(t(this).data("bg"))
    }), t(".nav-semi-dark").on("click", function() {
        p(v), h("light"), u(v), C(v, "navbar-semi-dark navbar-shadow"), t("input[name=nav-sdark-clr].default").prop("checked", !0), m = !(d = !1)
    }), t("input[name='nav-sdark-clr']").change(function() {
        1 == d && a.removeClass("navbar-semi-light").addClass("navbar-semi-dark");
        var a = t(".navbar-header"),
            e = p(a);
        a.removeClass(e).addClass(t(this).data("bg"))
    }), t(".nav-dark").on("click", function() {
        p(v), h("light"), u(v), C(v, "navbar-dark"), t("input[name=nav-dark-clr].default").prop("checked", !0)
    }), t("input[name='nav-dark-clr']").change(function() {
        var a = p(v);
        v.removeClass(a).addClass(t(this).data("bg"))
    }), t(".nav-light").on("click", function() {
        p(v), h("dark"), u(v), C(v, "navbar-light navbar-shadow"), t("input[name=nav-light-clr].default").prop("checked", !0)
    }), t("input[name='nav-light-clr']").change(function() {
        var a = p(v);
        v.removeClass(a).addClass(t(this).data("bg"))
    })
}(window, document, jQuery);