"use strict";
function dragNdrop(event) {
    var fileName = URL.createObjectURL(event.target.files[0]);
   /* var preview = document.getElementById("preview");
    var previewImg = document.createElement("img");
    previewImg.setAttribute("src", fileName);
    preview.innerHTML = "";
    preview.appendChild(previewImg);*/
}
function drag() {
    document.getElementById('uploadFile').parentNode.className = 'draging dragBox';
}
function drop() {
    document.getElementById('uploadFile').parentNode.className = 'dragBox';
}
//addVarient
function addVarient (argument) {
    var table = document.getElementById("variant-table");
    var t1=(table.rows.length);
    var t = t1 - 1;
    var row = table.insertRow(t1);
    var cell0 = row.insertCell(0);
    var cell1 = row.insertCell(1);
    var cell2 = row.insertCell(2);
    var cell3 = row.insertCell(3);
      /*cell1.className='abc';
      cell2.className='abc';*/
      row.className = "new-row";
      cell3.className='text-center';
    $('<span class="tabledit-span" >'+t1+'</span>').appendTo(cell0)
     $('<select class="form-control form-select "  onchange="GetNewVariant(this.value)"><option value="0">Click to select item</option><option value="1">AIDE-00001 Bakery and Bread</option><option value="1">AIDE-00002 Pasta and Rice</option><option value="add" ><i class="fa fa-plus"></i>Add New Variants</option></select>').appendTo(cell1);
     $('<div class="case-sensitive form-control" data-tags-input-name="case-sensitive"></div>').appendTo(cell2);
     $('<a href=""><i class="fa fa-file-o"></i></a> &nbsp;&nbsp;&nbsp; <a href="" class=""><i class="fa fa-refresh"></i></a>&nbsp;&nbsp;&nbsp;<a href="" class="transh-icon-color"><i class="fa fa-trash-o"></i></a>').appendTo(cell3);
    
}
function GetNewVariant(value,type = ""){
    if(value == 'add'){
        if(type == 3){
        $('#add-new-composite').modal('show')
     }else{
         $('#add-new-variant').modal('show')
     }
    }
}

function addCompositeItem(argument){
      var table = document.getElementById("composite-item-table");
    var t1=(table.rows.length);
    var row = table.insertRow(t1);
    var cell0 = row.insertCell(0);
    var cell1 = row.insertCell(1);
    var cell2 = row.insertCell(2);
    var cell3 = row.insertCell(3);
    var cell4 = row.insertCell(4);
    var cell5 = row.insertCell(5);
      /*cell1.className='abc';
      cell2.className='abc';*/
      row.className = "new-row";
      cell5.className='text-center';

     $('<span class="tabledit-span" >..</span>').appendTo(cell0)
     $('<select class="form-control form-select "  onchange="GetNewVariant(this.value)"><option value="0">Click to select item</option><option value="1">AIDE-00001 Bakery and Bread</option><option value="1">AIDE-00002 Pasta and Rice</option><option value="add" ><i class="fa fa-plus"></i>Add New Variants</option></select>').appendTo(cell1);
     $('').appendTo(cell2);
     $('').appendTo(cell3);
     $('').appendTo(cell4);
     $('<a href=""><i class="fa fa-file-o"></i></a> &nbsp;&nbsp;&nbsp; <a href="" class=""><i class="fa fa-refresh"></i></a>&nbsp;&nbsp;&nbsp;<a href="" class="transh-icon-color"><i class="fa fa-trash-o"></i></a>').appendTo(cell5);
    
}
$(".toggle-explore").click(function(){
  
  $(this).toggleClass("fa-angle-right fa-angle-up");
    $(this).closest("tr").next("tr").toggleClass("explore-Row"); 
 
}); 

function addItemField(){
 var table = document.getElementById("myTable");
    var t1=(table.rows.length);
    var t = t1 - 1;
    console.log(t);
    var row = table.insertRow(t1);
    var cell0 = row.insertCell(0);
    var cell1 = row.insertCell(1);
    var cell2 = row.insertCell(2);
    var cell3 = row.insertCell(3);
    // var cell4 = row.insertCell(4);
    
    row.className = "new-row";
    cell0.className='text-center ';
    cell3.className='text-center';
     // $('<span class="tabledit-span" >'+t1+'</span>').appendTo(cell0)
     $('<span class="tabledit-span" >..</span>').appendTo(cell0)
     $('<input class="tabledit-input form-control" type="text" name="sub['+t+'][subcategory_name]" id="sub['+t+']subcategory_name[]" value=""  >').appendTo(cell1);
     $('<input class="tabledit-input form-control" type="text" name="sub['+t+'][sub_description]" id="sub['+t+']sub_description[]" value=""  >').appendTo(cell2);
     $('<a href="#" class="transh-icon-color item-remove"><i class="fa fa-trash-o"></i></a>').appendTo(cell3);
    
}



